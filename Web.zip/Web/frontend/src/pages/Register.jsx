import Form from "../component/Form"

function Register() {
    return <Form route="/api/user/register/" method="register" />
}

export default Register;